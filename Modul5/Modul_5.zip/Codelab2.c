#include <stdio.h>

int main() {
    int i;
    int toko[2][3] = {
        {5, 8, 6}, {3, 7, 9} 
    };
    int total[3];
    int totalSemua = 0;
  
    for (i = 0; i < 3; i++) {
        total[i] = toko[0][i] + toko[1][i];
    }
    
    printf("Total penjualan untuk setiap produk:\n");
    for (i = 0; i < 3; i++) {
        printf("Produk %c: %d\n", 'A' + i, total[i]);
    }

    for (i = 0; i < 3; i++) {
        totalSemua += total[i];
    }
    printf("\nTotal penjualan: %d\n", totalSemua);

    return 0;
}
